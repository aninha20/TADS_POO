package resolucao;

public class Brinquedo {
	private String nome;
	private String faixaEtaria;
	private float preco;
	
	//métodos construtores necessários
	public Brinquedo() {
		
	}
	
	public Brinquedo(String nome) {
		this.nome = nome;
	}
	
	public Brinquedo(String nome, float preco) {
		this.nome = nome;
		this.preco = preco;
	}
	
	//métodos get e set de nome
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	
	//métodos get e set para faixa etaria
	public void setFaixaEtaria(String faixaEtaria) {
		if(faixaEtaria.equals("0 a 2") || faixaEtaria.equals("3 a 5") || faixaEtaria.equals("5 a 6") || faixaEtaria.equals("acima de 10")) {
			this.faixaEtaria = faixaEtaria;
		}else {
			System.out.println("A faixa etaria fornecida é inválida");
		}
			
	}
	
	public String getFaixaEtaria() {
		return faixaEtaria;
	}
	
	//métodos get e set de preco
	public void setPreco(float preco) {
		this.preco = preco;
	}
	
	public float getPreco() {
		return preco;
	}
	
	//método para mostrar os valores
	public void mostrar() {
		System.out.println("\nNome do brinquedo: " + getNome() + "\nFaixa Etaria: " + getFaixaEtaria() +"\npreco: " + getPreco());
	}
}
