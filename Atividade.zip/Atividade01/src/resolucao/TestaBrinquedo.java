package resolucao;

public class TestaBrinquedo {

	public static void main(String[] args) {
		Brinquedo brinquedo01 = new Brinquedo();
		Brinquedo brinquedo02 = new Brinquedo("Lego"); //passando argumento pelo método construtor
		Brinquedo brinquedo03 = new Brinquedo("Quebra-cabeça", 45.0f);
		
		//Testando métodos GET e SET com o objeto 'brinquedo01'
		brinquedo01.setNome("Agente Secreto");
		brinquedo01.setFaixaEtaria("acima de 10");
		brinquedo01.setPreco(140.99f);
		
		//Mostrando o conteúdo do objeto 'brinquedo01' por meio da função 'mostrar()'
		brinquedo01.mostrar();
		
		//Mostrando o conteúdo do objeto 'brinquedo02' por meio da função 'mostrar()'
		brinquedo02.mostrar();
		
		//Mostrando o conteúdo do objeto 'brinquedo03' por meio da função 'mostrar()'
		brinquedo03.mostrar();
		
		//verificar se o nome do objeto 'brinquedo02' irá mudar(teste)
		brinquedo02.setNome("Jogo da mamória");
		brinquedo02.mostrar();
	}

}
