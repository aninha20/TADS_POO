package resolucao;

class Data extends Tempo {
   private int dia;
   private int mes;
   private int ano;
   
   //método construtor com a validação dos dados que formam uma data
   public Data(int dia, int mes, int ano) {
      if (mes >= 1 && mes <= 12) {
         if (dia >= 1 && dia <= 30) {
            if (ano < 0) {
               throw new IllegalArgumentException("Ano deve ser positivo.");
            } else {
               this.dia = dia;
               this.mes = mes;
               this.ano = ano;
            }
         } else {
            throw new IllegalArgumentException("Dia deve estar entre 1 e 30.");
         }
      } else {
         throw new IllegalArgumentException("Meses deve estar entre 1 e 12.");
      }
   }
   
   //início dos métodos get e set
   public void setDia(int dia) {
      this.dia = dia;
   }

   public int getDia() {
      return this.dia;
   }

   public void setMes(int mes) {
      this.mes = mes;
   }

   public int getMes() {
      return this.mes;
   }

   public void setAno(int ano) {
      this.ano = ano;
   }

   public int getAno() {
      return this.ano;
   }
   
   //implementação do método quantidade(), realizado para efetuar a conta em segundos da data
   public int quantidade() {
      return this.ano * 31104000 + this.mes * 2592000 + this.dia * 86400;
   }
   
   public String toString() {
      return this.dia + "/" + this.mes + "/" + this.ano;
   }
}
