package resolucao;

class Horario extends Tempo {
   private int horas;
   private int minutos;
   private int segundos;
   
   //método construtor com a validação dos dados que referentes ao horário
   public Horario(int horas, int minutos, int segundos) {
      if (horas >= 0 && horas <= 24) {
         if (minutos >= 0 && minutos <= 60) {
            if (segundos >= 0 && segundos <= 60) {
               this.horas = horas;
               this.minutos = minutos;
               this.segundos = segundos;
               
            } else {
               throw new IllegalArgumentException("Segundo deve estar entre 0 e 60.");
            }
         } else {
            throw new IllegalArgumentException("Minuto deve estar entre 0 e 60.");
         }
      } else {
         throw new IllegalArgumentException("Hora deve estar entre 0 e 24.");
      }
   }
   
   //métodos get e set
   public void setHora(int horas) {
      this.horas = horas;
   }

   public int getHora() {
      return this.horas;
   }

   public void setMinuto(int minutos) {
      this.minutos = minutos;
   }

   public int getMinuto() {
      return this.minutos;
   }

   public void setSegundos(int segundos) {
      this.segundos = segundos;
   }

   public int getSegundos() {
      return this.segundos;
   }
   
   //método quantidade(), realizado para calcular o tempo em segundos
   public int quantidade() {
      return this.horas * 3600 + this.minutos * 60 + this.segundos;
   }

   public String toString() {
      return this.horas + ":" + this.minutos + ":" + this.segundos;
   }
}
