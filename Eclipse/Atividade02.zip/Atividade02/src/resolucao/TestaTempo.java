package resolucao;

import java.util.Scanner;

public class TestaTempo {
	//método para exibir as informações do objeto tempo
	public static void dadosTempo(Tempo oTempo) {
		if(oTempo == null) {
			System.out.println("Tipo inexistente");
		}
        System.out.println("Tempo formatado: " + oTempo.toString());
        System.out.println("Tempo em segundos: " + oTempo.quantidade());
    }

    public static void main(String[] args) {
    	 Scanner scanner = new Scanner(System.in);

         if (args.length < 5) {
             System.out.println("Digite o tipo (tempo, data, horario):");
             String tipo = scanner.nextLine();

             System.out.println("Digite o primeiro valor:");
             int valor1 = scanner.nextInt();

             System.out.println("Digite o segundo valor:");
             int valor2 = scanner.nextInt();

             System.out.println("Digite o terceiro valor:");
             int valor3 = scanner.nextInt();

            args = new String[] {tipo, String.valueOf(valor1), String.valueOf(valor2), String.valueOf(valor3)};
         }
        
        //passando o valor dos indices para variáveis
        String tipo = args[0];
        int valor1 = Integer.parseInt(args[1]);
        int valor2 = Integer.parseInt(args[2]);
        int valor3 = Integer.parseInt(args[3]);
        
        //objeto tempo da classe tempo
        Tempo oTempo = null;
        
        //verificação do tipo
        switch (tipo.toLowerCase()) {
            case "tempo":
                oTempo = new Tempo();
                break;

            case "horario":
                oTempo = new Horario(valor1, valor2, valor3);
                break;

            case "data":
                oTempo = new Data(valor1, valor2, valor3);
        }
        
        //chamando o método dadosTempo()
        dadosTempo(oTempo);
    }
}

